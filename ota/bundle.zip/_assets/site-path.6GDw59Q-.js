function r(e){return`${"/".replace(/\/$/,"")}/${e.replace(/^\//,"")}`}export{r as s};
